 <div class="row">
  <div class="col-3">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#" role="tab" aria-controls="v-pills-home" aria-selected="true">Jurnal Modul 10</a>
      <a class="nav-link" id="v-pills-adddata-tab" data-toggle="pill" href="inputdata.php" role="tab" aria-controls="v-pills-adddata" aria-selected="false">Tambah Data</a>
      <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="profile.php" role="tab" aria-controls="v-pills-profile" aria-selected="false">Lihat Profile</a>
      <a class="nav-link" id="v-pills-logout-tab" data-toggle="pill" href="logout.php" role="tab" aria-controls="v-pills-logout" aria-selected="false">Logout</a>
    </div>
  </div>
  <div class="col-9">
    <div class="tab-content" id="v-pills-tabContent">
 <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">...</div>
      <div class="tab-pane fade" id="v-pills-adddata" role="tabpanel" aria-labelledby="v-pills-adddata-tab">...</div>
      <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">...</div>
      <div class="tab-pane fade" id="v-pills-logout" role="tabpanel" aria-labelledby="v-pills-logout-tab">...</div>
    </div>
    </div>
  </div>
</div>